# Youtube_Merger

In this project we are making a mashup of n audio files using the following steps:<br>
i) First, we are randomly downloading N videos of X singer from “Youtube”<br>
ii) Then we are convert all the videos to audio and cut first Y sec audios from all downloaded files.<br> 
iii) At last we are merging all audios to make a single output file (mp3).<br>

The syntax to run the file is (5 input parameters): <b> python  ScriptName  SingerName  NumberOfVideos  AudioDuration(in sec)  OutputFileName(in mp3 format)</b><br>
Eg: python Mashup.py "Taylor Swift" 3 60 Mashup.mp3 (Mashup.mp3 will be the merged output file).
